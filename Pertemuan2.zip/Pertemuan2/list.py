

##accest list
# thislist = ["apple", "banana", "cherry"]
# print(thislist[-1])


# list1 = ["a", "b", "c"]
# list2 = [1, 2, 3]

# list3 = list1 + list2
# print(list3)



## add list 
# thislist = ["apple", "banana", "cherry"]
# thislist.append("orange")
# print(thislist)

thislist = ["apple", "banana", "cherry"]
thislist.insert(1, "orange")
print(thislist)
# list1 = ["a", "b" , "c"]
# list2 = [1, 2, 3]

# for x in list2:
#   list1.append(x)

# print(list1)